package ArvoreBinaria;

public class Noh {

    Aluno aluno;
    Noh left;
    Noh right;

    public Noh(Aluno aluno) {
        this.aluno = aluno;
        this.left = null;
        this.right = null;
    }

}
