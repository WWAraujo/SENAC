package org.example;

import ArvoreBinaria.Aluno;
import ArvoreBinaria.Arvore;

public class Main {
    public static void main(String[] args) {

    }
}